def compara_e_troca(vetor, i, j, ascendente):
    if(ascendente and vetor[i] > vetor[j]) or (not ascendente and vetor[i] < vetor[j]):
        aux = vetor[i]
        vetor[i] = vetor[j]
        vetor[j] = aux

def bitonicMerge(vetor, inicio, tamanho, ascendente):
    if tamanho > 1:
        meio = int(tamanho/2)
        for i in range(inicio, inicio + meio):
            compara_e_troca(vetor, i, i+ meio, ascendente)
        bitonicMerge(vetor, inicio, meio, ascendente)
        bitonicMerge(vetor, inicio + meio, meio, ascendente)




def bitonicSort(vetor, inicio, tamanho, ascendente=True):
    if tamanho > 1:
        meio = int(tamanho/2)
        bitonicSort(vetor, inicio, meio, True)
        bitonicSort(vetor, inicio + meio, meio, False)
        bitonicMerge(vetor, inicio, tamanho, ascendente)
    return vetor


if __name__ == "__main__":
    vetorDesordenado = [428, 16, 4, 25, 30, 54, 12, 3317]
    print("Vetor Desordenado:", vetorDesordenado)
    tamanho_vetor = len(vetorDesordenado)
    ordenaca_ascendente = True
    inicio_indice = 0

#     bitonic = bitonicSort(vetorDesordenado, inicio_indice, tamanho_vetor, ordenaca_ascendente)
#     print('Vetor Ordenado: ', bitonic)