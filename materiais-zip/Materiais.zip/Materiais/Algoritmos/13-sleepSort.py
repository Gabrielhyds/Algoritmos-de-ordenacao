import threading
import time

def sleepTime(valor):
    time.sleep(valor)
    print(valor)


def sleepSort(vetor):
    threads = []
    
    for num in vetor:
        thread = threading.Thread(target=sleepTime, args=(num,))
        threads.append(thread)
        thread.start()
    
    for thread in threads:
        thread.join()
    
if __name__ == "__main__":
    vetorDesordenado =  [0.001, 0.00016, 1.04, 2.025, 3.0, 0.04, 1.02, 0.3317, 7, 5, 3, 4, 6, 11]
    print(vetorDesordenado)
    sleepSort(vetorDesordenado)