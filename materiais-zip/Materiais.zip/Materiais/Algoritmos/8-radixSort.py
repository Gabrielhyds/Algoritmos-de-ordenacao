def countingSort(vetor, exp):
    count = [0] * 10
    n = len(vetor)

    for i in range(n):
        index = int((vetor[i]*100)//exp)  # Multiplicando por 100 para manter duas casas decimais
        count[index % 10] += 1

    for i in range(1, 10):
        count[i] += count[i - 1]
    
    saida = [0] * n
    i = n - 1

    while i >= 0:
        index = int((vetor[i]*100) // exp)  # Multiplicando por 100 para manter duas casas decimais
        saida[count[index % 10] - 1] = vetor[i]
        count[index % 10] -= 1
        i -= 1

    for i in range(n):
        vetor[i] = saida[i]

    return vetor

def radixSort(vetor):
    max_elemento = int(max(vetor)*100)  # Multiplicando por 100 para manter duas casas decimais

    exp = 1
    while max_elemento // exp > 0:
        countingSort(vetor, exp)
        exp *= 10

    return vetor

if __name__ == "__main__":
    # vetorDesordenado = [170, 45, 75, 90, 802, 24, 2, 66]
    vetor = [0.897, 0.565, 0.656, 0.1234, 343.665, 0.3434]
    print("Vetor original é:", vetor)
    resultado = radixSort(vetor)
    print("Vetor ordenado é:", resultado)
