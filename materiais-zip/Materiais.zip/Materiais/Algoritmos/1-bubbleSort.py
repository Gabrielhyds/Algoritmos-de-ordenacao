def bubbleSort(vetor):
    n = len(vetor)  
    j = True  
    while j:  
        j = False  
        for i in range(n-1):  # O(N)
            if vetor[i] > vetor[i+1]:  
                # troca
                aux = vetor[i] 
                vetor[i] = vetor[i+1] 
                vetor[i+1] = aux
                j = True
        n = n-1  

    return vetor

if __name__ == "__main__":
    # vetorDesordenado = [16, 428, 25, 4, 54, 30]
    vetorDesordenado = [4.4, 16.11, 25.12, 30.3, 54.5, 428]
    print('Vetor Desordenado',vetorDesordenado)
    print('Vetor Ordenado', bubbleSort(vetorDesordenado))