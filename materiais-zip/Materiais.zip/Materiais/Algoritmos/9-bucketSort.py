import insertionSort

def bucketSort(vetor):

    if len(vetor) == 0:
        return vetor 
    
    maior = max(vetor)
    menor = min(vetor)

    bucket_tamanho = (maior - menor) / len(vetor)


    buckets = [[] for _ in range(len(vetor))]


    for num in vetor:
        indice = int((num - menor) / bucket_tamanho)
        # print(num, menor, bucket_tamanho, indice)
        if indice == len(vetor):
            indice -= 1
        
        buckets[indice].append(num)

    
    for i in range(len(buckets)):
        buckets[i] = insertionSort.insertionSort(buckets[i])
    
    resultado = []

    for bucket in buckets:
        resultado += bucket

    return resultado
    

if __name__ == "__main__":
    vetorDesordenado = [3.1, 2.5, 4.0, 1.3, 2.8, 3.5]
    print(vetorDesordenado)
    bucket = bucketSort(vetorDesordenado)
    print(bucket)