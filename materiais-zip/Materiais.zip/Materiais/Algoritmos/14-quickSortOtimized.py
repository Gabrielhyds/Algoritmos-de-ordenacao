def mediana_3(vetor, inicio, meio, fim):
    A = vetor[inicio]
    B = vetor[meio]
    C = vetor[fim]

    if (A <= B and B <= C) or (C <= B and B <= A):
        return meio
    if (B <= A and A <= C) or (C <= A and A <= B):
        return inicio
    if (B <= C and C <= A) or (A <= C and C <= B):
        return fim

def particiona(vetor, inicio, fim):
    i = inicio
    j = fim
    meio = (inicio + fim) // 2
    pivo_index = mediana_3(vetor, inicio, meio, fim)
    pivo = vetor[pivo_index]

    while i < j:
        while i <= fim and vetor[i] <= pivo:
            i += 1
        while j >= 0 and vetor[j] > pivo:
            j -= 1
        
        if i < j:
            vetor[i], vetor[j] = vetor[j], vetor[i]

    vetor[inicio] = vetor[j]
    vetor[j] = pivo

    return j


def quickSortOtimized(vetor, inicio, fim):
    if fim > inicio:
        pivo = particiona(vetor, inicio, fim)
        quickSortOtimized(vetor, inicio, pivo - 1)
        quickSortOtimized(vetor, pivo + 1, fim)

    return vetor

# if __name__ == "__main__":
#     # vetorDesordenado = [38, 27, 43, 3, 9, 82, 10]
#     vetorDesordenado =  [0.001, 0.00016, 1.04, 2.025, 3.0, 0.04, 1.02, 0.3317, 7, 5, 3, 4, 6, 11]
#     print("Veor Desordenado", vetorDesordenado)
#     quick = quickSortOtimized(vetorDesordenado, 0, len(vetorDesordenado)-1)
#     print("Veor Ordenado", quick)