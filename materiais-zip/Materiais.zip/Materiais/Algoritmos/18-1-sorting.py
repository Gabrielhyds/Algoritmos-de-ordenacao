import numpy as np
import time

def insertionSort_visualization(vetor, func_chave, altura, largura, iteracoes = 100):
    n = len(vetor)
    contador_iteracoes = 0
    tempo_inicio = time.time()
    for i in range(1, n):
        aux = vetor[i]
        j = i
        while j > 0 and func_chave(aux) < func_chave(vetor[j-1]):
            vetor[j] = vetor[j-1]
            j = j - 1
        vetor[j] = aux


        contador_iteracoes += 1
        if contador_iteracoes % iteracoes == 0 or i == n -1:
            matriz_pixel_ordenada = np.array(vetor).reshape((altura, largura))
            matriz_pixel_transformada = np.array([[list(item.values())[0] for item in row] for row in matriz_pixel_ordenada])
            yield matriz_pixel_transformada, contador_iteracoes


    tempo_fim = time.time()
    tempo_execucao = tempo_fim - tempo_inicio
    print(f"Tempo de execução: {tempo_execucao:.4f} segundos")
    print(f"Número total de iterações: {contador_iteracoes}")


def selectionSort_visualization(vetor, func_chave, altura, largura, iteracoes = 100):
    n = len(vetor)
    contador_iteracoes = 0
    tempo_inicio = time.time()
    for i in range(n-1):
        minimo = i
        for j in range(i+1, n):
            if func_chave(vetor[j]) < func_chave(vetor[minimo]):
                minimo = j
        if i != minimo:
            aux = vetor[i]
            vetor[i] = vetor[minimo]
            vetor[minimo] = aux


        contador_iteracoes += 1
        if contador_iteracoes % iteracoes == 0 or i == n-1:
            matriz_pixel_ordenada = np.array(vetor).reshape((altura, largura))
            matriz_pixel_transformada = np.array([[list(item.values())[0] for item in row] for row in matriz_pixel_ordenada])
            yield matriz_pixel_transformada, contador_iteracoes


    tempo_fim = time.time()
    tempo_execucao = tempo_fim - tempo_inicio
    print(f"Tempo de execução: {tempo_execucao:.4f} segundos")
    print(f"Número total de iterações: {contador_iteracoes}")




def criar_heap(vetor, n, i, func_chave):
    maior = i
    esq = 2 * i + 1
    dir = 2 * i + 2

    if esq < n and func_chave(vetor[esq]) > func_chave(vetor[maior]):
        maior = esq
    if dir < n and func_chave(vetor[dir]) > func_chave(vetor[maior]):
        maior = dir

    if maior != i:
        aux = vetor[i]
        vetor[i] = vetor[maior]
        vetor[maior] = aux
        return criar_heap(vetor, n, maior, func_chave)


def heap_sort_visualization(vetor, func_chave, altura, largura, iteracoes = 100):
    n = len(vetor)
    contador_iteracoes = 0
    tempo_inicio = time.time()
    for i in range(((n//2)-1), -1, -1):
        criar_heap(vetor, n, i, func_chave)

    for i in range(n - 1, 0, -1):
        aux = vetor[0]
        vetor[0] = vetor[i]
        vetor[i] = aux
        criar_heap(vetor, i, 0, func_chave)

        contador_iteracoes += 1
        if contador_iteracoes % iteracoes == 0 or i == n-1:
            matriz_pixel_ordenada = np.array(vetor).reshape((altura, largura))
            matriz_pixel_transformada = np.array([[list(item.values())[0] for item in row] for row in matriz_pixel_ordenada])
            yield matriz_pixel_transformada, contador_iteracoes


    tempo_fim = time.time()
    tempo_execucao = tempo_fim - tempo_inicio
    print(f"Tempo de execução: {tempo_execucao:.4f} segundos")
    print(f"Número total de iterações: {contador_iteracoes}")



def margeSort_visualization(vetor, func_chave, altura, largura, iteracoes = 100):

    def merge(vetor, inicio, meio, fim):
        n = fim - inicio + 1
        parte1Inicio = inicio
        parte2Inicio = meio + 1
        parte1Fim = False
        parte2Fim = False 

        aux = [0 for i in range(n)]

        for i in range(n):
            if (not parte1Fim and not parte2Fim):
                if func_chave(vetor[parte1Inicio]) < func_chave(vetor[parte2Inicio]):
                    aux[i] = vetor[parte1Inicio]
                    parte1Inicio = parte1Inicio + 1
                else: 
                    aux[i] = vetor[parte2Inicio]
                    parte2Inicio = parte2Inicio + 1

                if parte1Inicio > meio:
                    parte1Fim = True

                if parte2Inicio > fim:
                    parte2Fim = True

            else:
                if not parte1Fim:
                    aux[i] = vetor[parte1Inicio]
                    parte1Inicio = parte1Inicio + 1
                else:
                    aux[i] = vetor[parte2Inicio]
                    parte2Inicio = parte2Inicio + 1

        k = inicio
        for j in range(n):
            vetor[k] = aux[j]
            k = k + 1


    def mergeSort(vetor, inicio, fim):
        if inicio < fim:
            meio = int((inicio + fim) / 2)
            mergeSort(vetor, inicio, meio) 
            mergeSort(vetor, meio + 1, fim) 
            merge(vetor, inicio, meio, fim)

    n = len(vetor)
    contador_iteracoes = 0
    tempo_inicio = time.time()

    for i in range (0, n, iteracoes):
        mergeSort(vetor, 0, min(i + iteracoes, n -1))
        matriz_pixel_ordenada = np.array(vetor).reshape((altura, largura))
        matriz_pixel_transformada = np.array([[list(item.values())[0] for item in row] for row in matriz_pixel_ordenada])
        yield matriz_pixel_transformada, i + 1

        contador_iteracoes +=1

    
    tempo_fim = time.time()
    tempo_execucao = tempo_fim - tempo_inicio
    print(f"Tempo de execução: {tempo_execucao:.4f} segundos")
    print(f"Número total de iterações: {contador_iteracoes}")

