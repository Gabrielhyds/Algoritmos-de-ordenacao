from heapSort import heap_sort
from quickSortOtimized import particiona
from insertionSort import insertionSort

def introSort(vetor, depth_limit=None):
    if depth_limit is None:
        depth_limit = 2 * (len(vetor) // 2).bit_length()

    introSort_util(vetor, 0, len(vetor)-1, depth_limit)

def introSort_util(vetor, inicio, fim, depth_limit):
    if fim - inicio > 16:
        if depth_limit == 0:
            heap_sort(vetor)
            return
        depth_limit -=1
        pivo = particiona(vetor, inicio, fim)
        introSort_util(vetor, inicio, pivo-1, depth_limit)
        introSort_util(vetor, pivo + 1, fim, depth_limit)
    else:
        insertionSort(vetor)

if __name__ == "__main__":
    vetorDesordenado = [2, 10, 24, 2, 10, 11, 27, 4, 2, 4, 28, 16, 9, 8, 28, 10, 13, 24, 22, 28, 0, 13, 27, 13, 3, 23, 18, 22, 8, 8, 383435345, 237, 43, 3, -9, -82, 10]
    print("Vetor Desordenado: ", vetorDesordenado)
    introSort(vetorDesordenado)
    print("Vetor Ordenado: ", vetorDesordenado)
    