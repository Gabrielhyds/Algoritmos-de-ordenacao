def particiona(vetor, inicio, fim):
    i = inicio
    j = fim
    pivo = vetor[inicio]

    while i < j:
        while i <= fim and vetor[i] <= pivo:
            i += 1
        while j >= 0 and vetor[j] > pivo:
            j -= 1
        
        if i < j:
            vetor[i], vetor[j] = vetor[j], vetor[i]

    vetor[inicio] = vetor[j]
    vetor[j] = pivo

    return j


def quickSort(vetor, inicio, fim):
    if fim > inicio:
        pivo = particiona(vetor, inicio, fim)
        quickSort(vetor, inicio, pivo - 1)
        quickSort(vetor, pivo + 1, fim)
        return vetor

if __name__ == "__main__":
    vetorDesordenado = [38, 27, 43, 3, 9, 82, 10]
    print("Vetor Desordenado:", vetorDesordenado)
    quick = quickSort(vetorDesordenado, 0, len(vetorDesordenado)-1)
    print("Vetor Ordenado: ", quick)
    

    