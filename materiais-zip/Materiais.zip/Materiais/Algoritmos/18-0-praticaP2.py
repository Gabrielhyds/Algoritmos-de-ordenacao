import matplotlib.pyplot as plt
import matplotlib.image as img
import numpy as np
from matplotlib.animation import FuncAnimation
from sorting import insertionSort_visualization, selectionSort_visualization, heap_sort_visualization, margeSort_visualization

imagem_teste = img.imread('img\sunflower100.jpg')

# plt.imshow(imagem_teste)
# plt.show()


altura , largura, canais = imagem_teste.shape

matriz_pixel = np.empty((altura, largura), dtype = object)

for i in range(altura):
    for j in range(largura):
        matriz_pixel[i, j] = {(i, j): imagem_teste[i, j].tolist()}

matriz_pixel_achatada = matriz_pixel.flatten()
np.random.shuffle(matriz_pixel_achatada)


fig, ax = plt.subplots()

imagem = ax.imshow(np.zeros((altura, largura, canais)), animated = True)

plt.title('Animação - Algoritmos de Ordenação')

def init():
    imagem.set_array(np.zeros((altura, largura, canais)))
    return imagem,


def update(frame,):
    pixels, iteracao = frame
    imagem.set_array(pixels)
    ax.set_title(f'Iteracao {iteracao}')
    return imagem,


# animacao = FuncAnimation(fig, update, frames = insertionSort_visualization(matriz_pixel_achatada, func_chave=lambda x: list(x.keys())[0], altura = altura, largura= largura, iteracoes = 100), init_func=init, blit = True)

# animacao = FuncAnimation(fig, update, frames = selectionSort_visualization(matriz_pixel_achatada, func_chave=lambda x: list(x.keys())[0], altura = altura, largura= largura, iteracoes = 100), init_func=init, blit = True, repeat=False)


# animacao = FuncAnimation(fig, update, frames = heap_sort_visualization(matriz_pixel_achatada, func_chave=lambda x: list(x.keys())[0], altura = altura, largura= largura, iteracoes = 100), init_func=init, blit = True, repeat=False)

animacao = FuncAnimation(fig, update, frames = margeSort_visualization(matriz_pixel_achatada, func_chave=lambda x: list(x.keys())[0], altura = altura, largura= largura, iteracoes = 100), init_func=init, blit = True, repeat=False)

plt.show()