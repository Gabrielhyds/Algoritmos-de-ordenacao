def merge(vetor, inicio, meio, fim):
    n = fim - inicio + 1
    parte1Inicio = inicio
    parte2Inicio = meio + 1
    parte1Fim = False
    parte2Fim = False 

    aux = [0 for i in range(n)]

    for i in range(n):
        if (not parte1Fim and not parte2Fim):
            if vetor[parte1Inicio] < vetor[parte2Inicio]:
                aux[i] = vetor[parte1Inicio]
                parte1Inicio = parte1Inicio + 1
            else: 
                aux[i] = vetor[parte2Inicio]
                parte2Inicio = parte2Inicio + 1

            if parte1Inicio > meio:
                parte1Fim = True

            if parte2Inicio > fim:
                parte2Fim = True

        else:
            if not parte1Fim:
                aux[i] = vetor[parte1Inicio]
                parte1Inicio = parte1Inicio + 1
            else:
                aux[i] = vetor[parte2Inicio]
                parte2Inicio = parte2Inicio + 1

    k = inicio
    for j in range(n):
        vetor[k] = aux[j]
        k = k + 1


def mergeSort(vetor, inicio, fim):
    if inicio < fim:
        meio = int((inicio + fim) / 2)
        mergeSort(vetor, inicio, meio) 
        mergeSort(vetor, meio + 1, fim) 
        merge(vetor, inicio, meio, fim)

    return vetor


if __name__ == "__main__":
    # vetorDesordenado = [16, 428, 25, 4, 54, 30]
    vetorDesordenado = [38, 27, 43, 3, 9, 82, 10]
    print("Vetor Desordenado:", vetorDesordenado)
    resultado = mergeSort(vetorDesordenado, 0, len(vetorDesordenado) - 1)
    print("Vetor Ordenado:", resultado)
