import random 
import timeit
import matplotlib.pyplot as plt
from mergeSort import mergeSort
from quickSort import quickSort
from radixSort import radixSort
from insertionSort import insertionSort
from selectionSort import selectionSort
from heapSort import heap_sort


def generate_random_data(size):
    return [random.randint(0, 100) for _ in range(size)]

sizes = [100, 200, 500, 1000, 2000, 3000, 4000, 5000]

merge_times = []
quick_times = []
radix_times = []
insertion_times = []
selection_times = []
heap_times = []


for size in sizes:
    dados_aleatorios = generate_random_data(size)

    merge_time = timeit.timeit(lambda: mergeSort(dados_aleatorios.copy(), 0, len(dados_aleatorios)-1), number=10)
    merge_times.append(merge_time)

    quick_time = timeit.timeit(lambda: quickSort(dados_aleatorios.copy(), 0, len(dados_aleatorios) - 1), number=10)
    quick_times.append(quick_time)

    radix_time = timeit.timeit(lambda: radixSort(dados_aleatorios.copy()), number=10)
    radix_times.append(radix_time)

    insertion_time = timeit.timeit(lambda: insertionSort(dados_aleatorios.copy()), number=10)
    insertion_times.append(insertion_time)

    selection_time = timeit.timeit(lambda: selectionSort(dados_aleatorios.copy()), number=10)
    selection_times.append(selection_time)

    heap_time = timeit.timeit(lambda: heap_sort(dados_aleatorios.copy()), number=10)
    heap_times.append(heap_time)


plt.plot(sizes, merge_times, label='mergeSort')
plt.plot(sizes, quick_times, label='quickSort')
plt.plot(sizes, radix_times, label='radixSort')
plt.plot(sizes, insertion_times, label='insertionSort')
plt.plot(sizes, selection_times, label='selectionSort')
plt.plot(sizes, heap_times, label='heapSort')

plt.xlabel('Tamanho da entrada')
plt.ylabel('Tempo médio (segundos)')
plt.title('Complexidade temporal')

plt.legend()


plt.text(sizes[-1], merge_times[-1], "Nerge Sort", fontsize=8, ha='left', va='bottom')
plt.text(sizes[-1], quick_times[-1], "Quick Sort", fontsize=8, ha='left', va='bottom')
plt.text(sizes[-1], radix_times[-1], "Radix Sort", fontsize=8, ha='left', va='bottom')
plt.text(sizes[-1], insertion_times[-1], "Insertion Sort", fontsize=8, ha='left', va='bottom')
plt.text(sizes[-1], selection_times[-1], "Selection Sort", fontsize=8, ha='left', va='bottom')
plt.text(sizes[-1], heap_times[-1], "Heap Sort", fontsize=8, ha='left', va='bottom')


plt.show()