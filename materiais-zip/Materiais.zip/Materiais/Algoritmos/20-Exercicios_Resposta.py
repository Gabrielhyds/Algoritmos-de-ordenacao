''' 
4- Durante as aulas você aprendeu que o Bubble Sort é o algoritmo mais lento, enquanto que o Quick Sort tem a tendência a serem mais rápidos. Para testar se efetivamente teremos resultados mais rápidos, siga o seguinte roteiro:
 	• Compare um algoritmo de cada classe (Algoritmos de Ordenação Simples, Algoritmos de Ordenação Eficientes - Baseado em Comparação, Algoritmos de Ordenação Não 	Comparativos, Algoritmos Híbridos, Algoritmos Adaptativos e Algoritmos Distribuído)
	• Crie um vetor com 5000 números (do tipo float) aleatórios entre 0 e 1 (utilize a biblioteca random)
	• Use o comando timeit para medir o desempenho e compare o tempo de execução de cada algoritmo
	• Lembre de utilizar o mesmo vetor em todos os experimentos!
Qual algoritmo foi mais rápido?
'''

import random
import numpy as np
import timeit

# importando os algoritmos
from bubbleSort import bubbleSort
from mergeSort import mergeSort
from bucketSort import bucketSort
from timSortOtimized import timSort
from smoothSort import smoothsort
from bitonicSort import bitonicSort



vetor = []
for _ in range(5000):
    vetor.append(round(random.random(), 4))
vetor = np.array(vetor)

print(vetor)

print("-----------------Testes nos algoritmos-------------------")

# Medindo o tempo de execução da função bubbleSort
tempo_execucao = timeit.timeit(lambda: bubbleSort(vetor.copy()), number=1)
print(f'Tempo de execução Bubble: {tempo_execucao} segundos')

tempo_execucao = timeit.timeit(lambda: mergeSort(vetor.copy(), 0, len(vetor)-1), number=1)
print(f'Tempo de execução Merge: {tempo_execucao} segundos')

tempo_execucao = timeit.timeit(lambda: bucketSort(vetor.copy()), number=1)
print(f'Tempo de execução Bucket: {tempo_execucao} segundos')


tempo_execucao = timeit.timeit(lambda: timSort(vetor.copy(), 5), number=1)
print(f'Tempo de execução Tim: {tempo_execucao} segundos')


tempo_execucao = timeit.timeit(lambda: smoothsort(vetor.copy()), number=1)
print(f'Tempo de execução Smooth: {tempo_execucao} segundos')


tempo_execucao = timeit.timeit(lambda: bitonicSort(vetor.copy(), 0, len(vetor), True), number=1)
print(f'Tempo de execução Bitonic: {tempo_execucao} segundos')



'''
6- Crie um programa que dado uma string, coloque as letras dela em ordem decrescente usando o algoritmo quick sort.
'''


# O novo quickSort ficaria assim:
def particiona(vetor, inicio, fim):
    i = inicio # continua o mesmo
    j = fim # continua o mesmo
    pivo = vetor[inicio][1]  # Usando o valor em minúsculas para comparação

    while i < j: # continua o mesmo
        while i <= fim and vetor[i][1] >= pivo: # muda de <= para >=; analisa os valores em maiúsculo
            i += 1 # continua o mesmo
        while j >= inicio and vetor[j][1] < pivo:# muda de > para <; analisa os valores em maiúsculo
            j -= 1 # continua o mesmo
        
        if i < j: # continua o mesmo
            aux = vetor[i] # continua o mesmo
            vetor[i] = vetor[j] # continua o mesmo
            vetor[j] = aux # continua o mesmo


    # Parte modificada para realizar a troca
    aux = vetor[inicio]
    vetor[inicio] = vetor[j]
    vetor[j] = aux

    return j # continua o mesmo


def quickSort(vetor, inicio, fim): # continua o mesmo
    if inicio < fim:  # muda de > para <
        pivo = particiona(vetor, inicio, fim) # continua o mesmo
        quickSort(vetor, inicio, pivo-1) # continua o mesmo
        quickSort(vetor, pivo+1, fim) # continua o mesmo
        return vetor # continua o mesmo


if __name__ == "__main__":
    string = input("Digite uma string: ")
    vetor_letras = [(letra, letra.lower()) for letra in string]  # Cria pares de letra original e letra em minúsculas
    quickSort(vetor_letras, 0, len(vetor_letras) - 1)
    string_ordenada = ''.join([letra[0] for letra in vetor_letras])  # Recupera as letras originais já ordenadas
    print("String em ordem decrescente:", string_ordenada)