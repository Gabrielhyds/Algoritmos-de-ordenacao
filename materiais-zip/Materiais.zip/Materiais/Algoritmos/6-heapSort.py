def criar_heap(vetor, n, i):
    maior = i
    esq = 2 * i + 1
    dir = 2 * i + 2

    if esq < n and vetor[esq] > vetor[maior]:
        maior = esq
    if dir < n and vetor[dir] > vetor[maior]:
        maior = dir

    if maior != i:
        aux = vetor[i]
        vetor[i] = vetor[maior]
        vetor[maior] = aux
        return criar_heap(vetor, n, maior)


def heap_sort(vetor):
    n = len(vetor)

    for i in range(((n//2)-1), -1, -1):
        criar_heap(vetor, n, i)

    for i in range(n - 1, 0, -1):
        aux = vetor[0]
        vetor[0] = vetor[i]
        vetor[i] = aux
        criar_heap(vetor, i, 0)

    return vetor

if __name__ == "__main__":
    vetorDesordenado = [383435345, 237, 43, 3, -9, -82, 10]
    print("Vetor Desordenado:", vetorDesordenado)
    heap = heap_sort(vetorDesordenado)
    print('Vetor Ordenado:', heap)
