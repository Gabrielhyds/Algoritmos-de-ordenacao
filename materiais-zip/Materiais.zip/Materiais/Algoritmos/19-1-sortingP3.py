def bubbleSort(vetor):
    n = len(vetor)  

    j = True  
    while j:  
        j = False  
        for i in range(n-1):  # O(N)
            if vetor[i] > vetor[i+1]:  
                # troca
                aux = vetor[i] 
                vetor[i] = vetor[i+1] 
                vetor[i+1] = aux
                j = True
                yield vetor
        n = n-1  

def selectionSort(vetor):
    n = len(vetor)
    for i in range(n-1):
        minimo = i
        for j in range(i+1, n):
            if vetor[j] < vetor[minimo]:
                minimo = j
        if i != minimo:
            aux = vetor[i]
            vetor[i] = vetor[minimo]
            vetor[minimo] = aux
        yield vetor


def insertionSort(vetor):
    n = len(vetor)
    for i in range(1, n):
        aux = vetor[i]
        j = i
        while j > 0 and aux < vetor[j-1]:
            vetor[j] = vetor[j-1]
            j = j - 1
            yield vetor
        vetor[j] = aux


def merge(vetor, inicio, meio, fim):
    n = fim - inicio + 1
    parte1Inicio = inicio
    parte2Inicio = meio + 1
    parte1Fim = False
    parte2Fim = False 

    aux = [0 for i in range(n)]

    for i in range(n):
        if (not parte1Fim and not parte2Fim):
            if vetor[parte1Inicio] < vetor[parte2Inicio]:
                aux[i] = vetor[parte1Inicio]
                parte1Inicio = parte1Inicio + 1
            else: 
                aux[i] = vetor[parte2Inicio]
                parte2Inicio = parte2Inicio + 1

            if parte1Inicio > meio:
                parte1Fim = True

            if parte2Inicio > fim:
                parte2Fim = True

        else:
            if not parte1Fim:
                aux[i] = vetor[parte1Inicio]
                parte1Inicio = parte1Inicio + 1
            else:
                aux[i] = vetor[parte2Inicio]
                parte2Inicio = parte2Inicio + 1

    k = inicio
    for j in range(n):
        vetor[k] = aux[j]
        k = k + 1


def mergeSort(vetor, inicio, fim):
    if inicio < fim:
        meio = int((inicio + fim) / 2)
        yield from mergeSort(vetor, inicio, meio) 
        yield from mergeSort(vetor, meio + 1, fim) 
        merge(vetor, inicio, meio, fim)
        yield vetor



def particiona(vetor, inicio, fim):
    i = inicio
    j = fim
    pivo = vetor[inicio]

    while i < j:
        while i <= fim and vetor[i] <= pivo:
            i += 1
        while j >= 0 and vetor[j] > pivo:
            j -= 1
        
        if i < j:
            vetor[i], vetor[j] = vetor[j], vetor[i]

    vetor[inicio] = vetor[j]
    vetor[j] = pivo
    yield vetor

    return j


def quickSort(vetor, inicio, fim):
    if fim > inicio:
        pivo = yield from particiona(vetor, inicio, fim)
        yield from quickSort(vetor, inicio, pivo - 1)
        yield from quickSort(vetor, pivo + 1, fim)


def criar_heap(vetor, n, i):
    maior = i
    esq = 2 * i + 1
    dir = 2 * i + 2

    if esq < n and vetor[esq] > vetor[maior]:
        maior = esq
    if dir < n and vetor[dir] > vetor[maior]:
        maior = dir

    if maior != i:
        aux = vetor[i]
        vetor[i] = vetor[maior]
        vetor[maior] = aux
        yield vetor
        yield from criar_heap(vetor, n, maior)


def heap_sort(vetor):
    n = len(vetor)

    for i in range(((n//2)-1), -1, -1):
        yield from criar_heap(vetor, n, i)

    for i in range(n - 1, 0, -1):
        aux = vetor[0]
        vetor[0] = vetor[i]
        vetor[i] = aux
        yield from criar_heap(vetor, i, 0)

    return vetor




def smoothsort(A):
    def numeros_leonardo(N):
        ln = [1, 1]
        while ln[-1] < N:
            ln.append(ln[-1] + ln[-2] + 1)
        ln.pop()
        return ln

    def sift_down(inicio, fim, incremento):
        raiz = inicio
        while raiz * 2 + 1 * incremento <= fim:
            filho = raiz * 2 + 1 * incremento
            troca = raiz
            if A[troca] < A[filho]:
                troca = filho
            if filho + 1 * incremento <= fim and A[troca] < A[filho + 1 * incremento]:
                troca = filho + 1 * incremento
            if troca == raiz:
                return
            else:
                aux = A[raiz]
                A[raiz] = A[troca]
                A[troca] = aux
                raiz = troca
            yield A

    # passo 1
    tamanho = len(A)
    if tamanho < 2:
        yield A
        return

    n_leo = numeros_leonardo(tamanho)

    # passo 2
    i = len(n_leo) - 1
    while i >= 0:
        p = n_leo[i]
        for j in range(p, tamanho):
            yield from sift_down(j - p, tamanho - 1, p)
        i -= 1

    # passo 3
    for i in range(tamanho - 1):
        aux = A[0]
        A[0] = A[tamanho - i - 1]
        A[tamanho - i - 1] = aux

        j = 0
        while j < len(n_leo) and n_leo[j] < tamanho - i - 2:
            j += 1
        yield from sift_down(0, tamanho - i - 2, 1)

        yield A



def encontrar_max_elemento(vetor):
    max_elemento = float('-inf')
    for elem in vetor:  
        if(elem > max_elemento):
            max_elemento = elem 
    return max_elemento 


def countingSort(vetor):
    # encontrar o maior elemento do vetor
    max_elemento = int(encontrar_max_elemento(vetor)) 
    # max_elemento = max(vetor) 
    count = [0] * (max_elemento + 1)
    # 3 parte  contagem de elementos
    for elemento in vetor: 
        count[int(elemento)] +=1 
    # 4 parte - somar os elementos
    for i in range(1, max_elemento +1): 
        count[i] += count[i-1] 

    resultado = [0] * len(vetor) 

    i = len(vetor) -1

    while i >= 0:
        elemento = vetor[i] 
        count[int (elemento)] -= 1 
        posicao = count[int (elemento)] 
        resultado[posicao] = elemento 
        i -= 1

        yield resultado


def countingSort_radix(vetor, exp):
    count = [0] * 10
    n = len(vetor)

    for i in range(n):
        index = int((vetor[i]*100)//exp)  # Multiplicando por 100 para manter duas casas decimais
        count[index % 10] += 1

    for i in range(1, 10):
        count[i] += count[i - 1]
    
    saida = [0] * n
    i = n - 1

    while i >= 0:
        index = int((vetor[i]*100) // exp)  # Multiplicando por 100 para manter duas casas decimais
        saida[count[index % 10] - 1] = vetor[i]
        count[index % 10] -= 1
        i -= 1

    for i in range(n):
        vetor[i] = saida[i]
        yield vetor

def radixSort(vetor):
    max_elemento = int(max(vetor)*100)  # Multiplicando por 100 para manter duas casas decimais

    exp = 1
    while max_elemento // exp > 0:
        yield from countingSort_radix(vetor, exp)
        exp *= 10


