import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as img
from radixSort import radixSort
from bubbleSort import bubbleSort
from introSort import introSort
from smoothSort import smoothSort
import time

testImage = img.imread('img\desenho.jpg')
# plt.imshow(testImage)
# plt.show()

pixels = np.array(testImage)
# print(pixels)

if len(pixels.shape) == 3:
    flattened_pixels = pixels.reshape(-1, pixels.shape[-1]) # (altura, largura, canais de cores)
    start_time = time.time()
    for channel in range(flattened_pixels.shape[1]):
        smoothSort(flattened_pixels[:, channel])
        # bubbleSort(flattened_pixels[:, channel])
else:
    flattened_pixels = pixels.flatten()
    start_time = time.time()
    smoothSort(flattened_pixels)
    # bubbleSort(flattened_pixels)

end_time = time.time()

sorted_image = flattened_pixels.reshape(pixels.shape)


print("Tempo de execução: ", end_time - start_time, "Segundos")

plt.imshow(sorted_image)
plt.show()
