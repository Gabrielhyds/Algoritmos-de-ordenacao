import numpy as np
import matplotlib.pyplot as plt


n = np.linspace(1, 10, 100)
fatoriais = np.array([np.prod(np.arange(1, elem+1) )for elem in n])

# print('Constante: ', np.ones(n.shape))
# print('Logarítmica: ', np.log(n))
# print('Linear: ', n) 
# print('Log Linear: ', n*np.log(n))
# print('Quadrática: ', n**2)
# print('Cúbica: ', n**3)
# print('Exponencial: ', 2**n)
# print('Fatorial: ', fatoriais)

labels = ['Constante', 'Logarítmica', 'Linear', 'Log Linear', 'Quadrática', 'Cúbica', 'Exponencial', 'Fatorial']

big_O_analise = [np.ones(n.shape), np.log(n), n, n*np.log(n), n**2, n**3,  2**n, fatoriais]


plt.figure(figsize=(10, 8))
plt.ylim(0, 100)
for i in range(len(big_O_analise)):
    plt.plot(n, big_O_analise[i], label=labels[i])
    plt.legend()
    plt.ylabel('Tempo de execução')
    plt.xlabel('N')

plt.show()