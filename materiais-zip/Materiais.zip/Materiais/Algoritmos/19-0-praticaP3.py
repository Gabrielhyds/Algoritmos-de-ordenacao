import matplotlib.pyplot as plt
import matplotlib.animation as animation
import csv
import sys
from sortingP3 import bubbleSort, insertionSort, selectionSort, heap_sort, smoothsort, countingSort, radixSort, mergeSort, quickSort

def mostrar_dados(atributo, caminho_arquivo):
    dados_atributo = []
    indice_atributo = {}

    with open(caminho_arquivo, newline='') as csvfile:
        leitor = csv.reader(csvfile, delimiter=';')
        cabecalho = next(leitor)
        for i, nome_atributo in enumerate(cabecalho):
            indice_atributo[nome_atributo] = i
        if atributo not in indice_atributo:
            print(f"O atributo '{atributo}' não foi encontrado no arquivo.")
            return
        indice = indice_atributo[atributo]

        for linha in leitor:
            try:
                valor = float(linha[indice])
            except ValueError:
                try:
                    valor = int(linha[indice])
                except ValueError:
                    valor = linha[indice]
            dados_atributo.append(valor)
    # print(f"Dados do atributo {atributo}")
    # for dado  in dados_atributo:
    #     print(dado)

    return dados_atributo

caminho_arquivo = "dados.csv"


while True:
    method = input("Entre com o método de ordenação: \n(b)ubble | (i)nsertion | (m)erge | (q)uick | (s)election | (h)eap | (sm)ooth | (c)ounting | (r)adix | (cls)Sair\n")
    if method == "cls":
        sys.exit()
    atributo = input("Digite o nome do atributo que deseja visualizar: ")
    N = int(input("Entre com o número de dados que se deseja ver: "))

    mostrar = mostrar_dados(atributo, caminho_arquivo)

    vetor = mostrar[:N]

    if method == "b":
        title = "BubbleSort"
        generator = bubbleSort(vetor)
    elif method == "s":
        title = "SelectionSort"
        generator = selectionSort(vetor)
    elif method == "i":
        title = "InsertionSort"
        generator = insertionSort(vetor)
    elif method == "m":
        title = "MergeSort"
        generator = mergeSort(vetor, 0, N - 1)
    elif method == "q":
        title = "QuickSort"
        generator = quickSort(vetor, 0, N - 1)
    elif method == "h":
        title = "HeapSort"
        generator = heap_sort(vetor) 
    elif method == "sm":
        title = "SmoothSort"
        generator = smoothsort(vetor)
    elif method == "c":
        title = "CountingSort"
        generator = countingSort(vetor)
    elif method == "r": 
        title = "RadixSort"
        generator = radixSort(vetor)
    else:
        sys.exit()

    fig, ax =plt.subplots()
    ax.set_title(title)

    bar_rects = ax.bar(range(len(vetor)), vetor, align = "edge")

    ax.set_xlim(0, N)
    ax.set_ylim(0, max(vetor))
    text = ax.text(0.02, 0.95, "", transform=ax.transAxes)

    iteration = [0]

    def update_fig(vetor, rects, iteration):
        for rect, val in zip(rects, vetor):
            rect.set_height(val)
        iteration[0] +=1
        text.set_text(f"N de operações: {iteration[0]}")

    
    anim = animation.FuncAnimation(fig, func=update_fig, fargs=(bar_rects, iteration), frames=generator, interval=1, repeat=False, save_count= 1000)

    plt.show()