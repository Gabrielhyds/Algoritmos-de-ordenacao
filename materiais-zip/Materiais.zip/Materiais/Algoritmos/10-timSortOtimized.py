from insertionSort import insertionSort
from mergeSort import merge


def min_run_tamanho(N, MIN_MERGE):
    if(N < 0):
        raise ValueError("O tamanho do vetor não pode ser negativo")
    r = 0
    while( N >= MIN_MERGE):
        r += N %2
        N //=2
    return N + r
    
def timSort(vetor, min_merge = 8):
    def encontrar_run(vetor, inicio, fim):
        run = 1
        ascendente = vetor[inicio] <= vetor[inicio + 1]

        for i in range(inicio+1, fim +1):
            if(ascendente and vetor[i-1] > vetor[i]):
                break
            elif not ascendente and vetor[i+1] <= vetor[i]:
                break
            run += 1
        return run

    def timSort_interno(vetor, inicio, fim):
        N = fim - inicio + 1
        minrum = min_run_tamanho(N, min_merge)
        run = encontrar_run(vetor, inicio, fim)


        if run <= minrum:
            insertionSort(vetor)
        else:
            meio = int((inicio + fim) / 2)
            timSort_interno(vetor, inicio, meio)
            timSort_interno(vetor, meio +1, fim)
            merge(vetor, inicio, meio, fim)

    timSort_interno(vetor, 0, len(vetor)-1)

    return vetor


if __name__ == "__main__":
    # vetorDesordenado =   [0.64, 34, 25, 12, -22, 11, 90]
    vetorDesordenado = [0, 1, -1, 2, -2 , 3, -3,4,-4,5,-5,6,-6,7,-7,8,-8,9,-9,10,
                        -10,11,-11,12,-12,13,-13,14,-14,15,-15,16,-16,17,-17,18,-18,19,-19,
                        20,-20,21,-21,22,-22,23,-23,24,-24,25,-25,26,-26,27,-27,28,-28,29,
                        -29,30,-30,31,-31,32,-32,33,-33,34,-34,35,-35,36,-36,37,-37,38,-38,
                        39,-39,40,-40,41,-41,42,-42,43,-43,44,-44,45,-45,46,-46,47,-47,48,-48,
                        49,-49,50, 9,-3,14,0,-7,2,-10,5,-1,8,-6,11,4,-2,7,-5,13,-8,1,-4,10,3,
                        -9,6,-11,12,-13,15,-12,17,-18,21,-16,19,-15,20,-14,23,-24,25,-22,27,
                        -26,29,-30,31,-28,33,-32,35,-34,37,-36,38,-39,41,-40,43,-42,45,-44,46,
                        -47,49,-48,51,-50,53,-52,55,-54,56,-57,59,-58,61,-60,63,-62,65,-64,67,
                        -66,69,-68,71,-70,73,-72,75,-74,76,-77,79,-78,81,-80,83,-82,85,-84,87,
                        -86,89,-88,91,-90,93,-92,95,-94,97,-96,99]
  
    # print(vetorDesordenado)
    MIN_MERGE = 5
    # N = 454654654654
    # minrum = min_run_tamanho(N, MIN_MERGE)
    # print("Minrum para o vetor de tamanho N: ", N, ":", minrum)
    tim_otimizado = timSort(vetorDesordenado, MIN_MERGE)
    print(tim_otimizado)