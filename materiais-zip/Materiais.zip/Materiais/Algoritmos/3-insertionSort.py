def insertionSort(vetor):
    n = len(vetor)
    for i in range(1, n):
        aux = vetor[i]
        j = i
        while j > 0 and aux < vetor[j-1]:
            vetor[j] = vetor[j-1]
            j = j - 1
        vetor[j] = aux

    return vetor


if __name__ == "__main__":
    vetorDesordenado = [16, 428, 25, 4, 54, 30]
    print(vetorDesordenado)
    print(insertionSort(vetorDesordenado))