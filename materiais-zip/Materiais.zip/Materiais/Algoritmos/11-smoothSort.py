def smoothsort(vetor):
    def numeros_leonardo(N):
        ln = [1, 1]
        while ln[-1] < N:
            ln.append(ln[-1] + ln[-2] + 1)
        ln.pop()
        return ln

    def sift_down(inicio, fim, incremento):
        raiz = inicio
        while raiz * 2 + 1 * incremento <= fim:
            filho = raiz * 2 + 1 * incremento
            troca = raiz
            if vetor[troca] < vetor[filho]:
                troca = filho
            if filho + 1 * incremento <= fim and vetor[troca] < vetor[filho + 1 * incremento]:
                troca = filho + 1 * incremento
            if troca == raiz:
                return
            else:
                aux = vetor[raiz]
                vetor[raiz] = vetor[troca]
                vetor[troca] = aux
                raiz = troca

    # passo 1
    tamanho = len(vetor)
    if tamanho < 2:
        return vetor

    n_leo = numeros_leonardo(tamanho)

    # passo 2
    i = len(n_leo) - 1
    while i >= 0:
        p = n_leo[i]
        for j in range(p, tamanho):
            sift_down(j - p, tamanho - 1, p)
        i -= 1

    # passo 3
    for i in range(tamanho - 1):
        aux = vetor[0]
        vetor[0] = vetor[tamanho - i - 1]
        vetor[tamanho - i - 1] = aux

        j = 0
        while j < len(n_leo) and n_leo[j] < tamanho - i - 2:
            j += 1
        sift_down(0, tamanho - i - 2, 1)

    return vetor


if __name__ == "__main__":
    vetorDesordenado = [3, 1, 4, 2, 11, 9, 6, 7, 0, 8, 5, 10, 4, 5, 6, 8, 234, 342, 543, 77883, 1231, 1, 3455, 0]
    print(vetorDesordenado)
    print(smoothsort(vetorDesordenado))