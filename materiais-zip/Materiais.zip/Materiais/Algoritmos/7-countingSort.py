def encontrar_max_elemento(vetor):
    max_elemento = vetor[0]
    for elem in vetor:  
        if(elem > max_elemento):
            max_elemento = elem 
    return max_elemento 


def countingSort(vetor):
    # encontrar o maior elemento do vetor
    max_elemento = encontrar_max_elemento(vetor) 
    # max_elemento = max(vetor) 
    count = [0] * (max_elemento + 1)
    # 3 parte  contagem de elementos
    for elemento in vetor: 
        count[elemento] +=1 
    # 4 parte - somar os elementos
    for i in range(1, max_elemento +1): 
        count[i] += count[i-1] 

    resultado = [0] * len(vetor) 

    i = len(vetor) -1

    while i >= 0:
        elemento = vetor[i] 
        count[elemento] -= 1 
        posicao = count[elemento] 
        resultado[posicao] = elemento 
        i -= 1
    return resultado




if __name__ == "__main__":
    # vetorDesordenado = [4, 2, 2, 8, 3, 3, 10]
    vetorDesordenado = [3, 1, 4, 2, 11, 9, 6, 7, 0, 8, 5, 10]
    print("Vetor Desordenado:", vetorDesordenado)
    counting = countingSort(vetorDesordenado)
    print("Vetor Ordenado:",counting)
   
