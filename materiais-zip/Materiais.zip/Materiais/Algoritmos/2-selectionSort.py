def selectionSort(vetor):
    n = len(vetor)
    for i in range(n-1):
        minimo = i
        for j in range(i+1, n):
            if vetor[j] < vetor[minimo]:
                minimo = j
        if i != minimo:
            aux = vetor[i]
            vetor[i] = vetor[minimo]
            vetor[minimo] = aux

    return vetor

if __name__ == "__main__":
    # vetorDesordenado = [16, 428, 25, 4, 54, 30]
    vetorDesordenado = [0.64, 34, 25, 12, -22, 11, 90]
    print(vetorDesordenado)
    print(selectionSort(vetorDesordenado))